from urllib2 import Request, urlopen
headers = {
	'Content-Type':'application/json; charset=UTF-8'
}
request = Request()