from bs4 import BeautifulSoup
import urllib2
import unicodedata
company_url = ["http://www.moneycontrol.com/india/newsarticle/news_print.php?autono=5489841&sr_no=0"];
url_2 = "&next=1&durationType=Y&Year="
url_3 = "&duration=1&news_type=";
year = [2015,2016]
pages = [21,19]
url = company_url[0];
news_url = []
date_time = []
date = []
time = []
news_content = []
content = urllib2.urlopen(url).read().decode('utf-8','ignore');
soup = BeautifulSoup(content,"html.parser");
print soup.find('td',class_='detail').text