import requests,json
url = "https://api.theysay.io/v1/sentiment"
score = '';
fopen = open('data_main/tcs_score2.csv','w');
for i in range(1414,1608):
	f = open('data_main/tcs/tcs' + str(i) + '.txt','rb');
	string_content = f.read();
	if len(string_content) <= 3500:
		content = json.dumps({'text':string_content,'level':'document'});
		r = requests.post(url,data=content,auth=('gautambathla@gmail.com','Ishei1Ahshai'),headers={'Content-Type':'application/json;charset=UTF-8'});
		result = json.loads(r.text);
		print result
		score = score + str(result['sentiment']['positive']) + ',' + str(result['sentiment']['negative']) + ',' + str(result['sentiment']['neutral']) + ',' + result['sentiment']['label'] + "\n";
	else:
		score += "\n";
fopen.write(score);
fopen.close();