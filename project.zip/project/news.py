from bs4 import BeautifulSoup
import urllib2
import unicodedata
company_url = ["http://ih.advfn.com/p.php?pid=news&btn=&ctl00%24sb3%24tbq1=&ctl00%24sb3%24stb1=Search+iHub&symbol=NASDAQ%3AMSFT&from_month=7&from_day=18&from_year=2016&srcoptions%5B%5D=reg_news&fulltext=&order=desc&srcoptions%5B%5D=nonreg_news&old_symbol=N%5EMSFT&old_fulltext=&old_sources=A&force=1&last_ts=1468886399&p_n="];
url_2 = "&p_count=0&p_ts=1468242000"
url = company_url[0];
news_url = []
date_time = []
date = []
time = []
news_content = []
for j in range(1,):
	content = urllib2.urlopen(url+str(j)+url_2).read().decode('utf-8','ignore');
	soup = BeautifulSoup(content,"html.parser");
	for link in soup.find_all('table',id='newsList'):
		news_url.append("http://www.moneycontrol.com"+link.find('a').get('href'));
		#for dates in soup.find_all('p',class_='PT3 a_10dgry'):
		#	date_time.append(dates.text.encode('utf-8').strip())
		#	print dates.text

#dates=[];
#fopen = open('data_main/tcs_news_dates.csv','w');
#content = '';
#for i in range(len(date_time)):
#	dates = date_time[i].split('|');
#	content = content + dates[1] + ',' + dates[0] + "\n";
#fopen.write(content);
#fopen.close();

print len(news_url);
for i in range(len(news_url)):
	start = news_url[i].index('_')
	end = news_url[i].index('.html')
	string = news_url[i]
	content_number = string[start+1:end]
	content_url = "http://www.moneycontrol.com/india/newsarticle/news_print.php?autono=" + content_number + "&sr_no=0"
	content = urllib2.urlopen(content_url).read().decode('utf-8','ignore');
	soup1 = BeautifulSoup(content,"html.parser");
	news_text = soup1.find('td',class_='detail').text
	text_file = open("data_main/tcs/tcs"+str(i+1)+".txt", "w")
	news_text = news_text.encode('ascii', 'ignore')
	text_file.write(news_text)
	text_file.close()