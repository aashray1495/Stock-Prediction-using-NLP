#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n,m;
    cin>>n>>m;
    string s[n];
    for(int i=0;i<n;i++)
    {
        cin>>s[i];
    }
    int flag1=0,flag2=0,row=-1,col=-1,prev_count,temp,col2=-1,row2=-1;
    for(int i=0;i<n;i++)
    {
        int counter=0;
        for(int j=0;j<m;j++)
        {
            if(s[i][j]=='*')
            {
                counter++;
                temp=j;
            }
        }
        if(counter>1)
        {
            if(flag1!=0)
            {

                flag1=2;
                break;
            }
            else
            {
                flag1=1;
                row=i;
            }
        }
        else if(counter==1)
        {
            col2=temp;
        }
    }
    for(int j=0;j<m;j++)
    {
        int counter=0;
        for(int i=0;i<n;i++)
        {
            if(s[i][j]=='*')
            {
                counter++;
                temp=i;
            }
        }
        if(counter>1)
        {

            if(flag2!=0)
            {

                flag2=2;
                break;
            }
            else
            {
                flag2=1;
                col=j;
            }
        }
        else if(counter==1)
        {
            row2=temp;
        }
    }

    if(flag1!=2 && flag2!=2)
    {
        if(row==-1)
        {
            row=0;
        }
        if(col==-1)
        {
            col=0;
        }
        if(flag1==1 || flag2==1)
        {
            int flag=0;
            for(int i=0;i<n;i++)
            {
                for(int j=0;j<m;j++)
                {
                    if(s[i][j]=='*')
                    {
                        if(i==row||j==col);
                        else
                        {
                            flag=1;
                            break;
                        }
                    }
                }
                if(flag==1)
                {
                    break;
                }
            }
            if(flag==0)
            cout<<"YES"<<endl<<row+1<<" "<<col+1;
            else
            {
                cout<<"NO"<<endl;
            }

        }
        else
        {
            int counter=0,row1,col1;
            for(int i=0;i<n;i++)
            {
                for(int j=0;j<m;j++)
                {
                    if(s[i][j]=='*')
                    {
                        counter++;
                        if(counter==1)
                        {
                            row=i;
                            col=j;
                        }
                        else if(counter==2)
                        {
                            row1=i;
                            col1=j;
                        }
                    }
                }
            }
            if(counter<2)
            {
                cout<<"YES"<<endl<<row+1<<" "<<col+1;
            }
            else if(counter==2)
            {
                cout<<"YES"<<endl<<row+1<<" "<<col1+1<<endl;
            }
            else
            {
                cout<<"NO"<<endl;
            }
        }
    }
    else
    {
        cout<<"NO"<<endl;
    }

}

