import csv
import nltk
import random
from nltk.corpus import stopwords
from nltk.corpus import movie_reviews

def binary_search(a, x, lo=0, hi=None):
    if hi is None:
        hi = len(a)
    while lo < hi:
        mid = (lo+hi)//2
        midval = a[mid]
        if midval < x:
            lo = mid+1
        elif midval > x: 
            hi = mid
        else:
            return mid
    return -1

def make_dictionary():
	f = open('dictionary.csv', 'rb')
	reader = csv.reader(f)
	word_list = [[]]
	for row in reader:
		#print row
		word_list.append([row[0].lower(),row[1].lower(),row[2].lower(),row[3].lower(),row[4].lower(),row[5].lower(),row[6].lower(),row[7].lower(),row[8].lower()])
	f.close()
	return word_list

def pos_dictionary():
	f = open('positive.csv', 'rb')
	reader = csv.reader(f)
	pos_list = []
	for row in reader:
		#print row
		pos_list.append(row[0])
	f.close()
	return pos_list

def neg_dictionary():
	f = open('negative.csv', 'rb')
	reader = csv.reader(f)
	neg_list = []
	for row in reader:
		#print row
		neg_list.append(row[0])
	f.close()
	return neg_list


def give_score(i,word_list,pos_list,neg_list,stopwords):
	score = 0
	flag = 0
	weight = 0
	negate = 0
	found = 0
	if i not in stop_words:
		for j in pos_list:
			if j==i:
				score = score + 1;
				score = score + weight;
				if weight == 2:
					weight = 0;
				found = 1;
		if found != 1:
			for j in neg_list:
				if j == i:
					score = score - 1;
					score = score - weight;
					if weight == 2:
						weight = 0;
					found = 1;
		if found != 1:	
			for j in range(1,len(word_list[:])):
				if i == word_list[j][0]:
					if word_list[j][1] != '':
						if word_list[j][4] != '':
							score = score + 2;
							score = score + weight;
							if weight == 2:
								weight = 0;
						elif word_list[j][5] != '':
							score = score + 0.5;
							score = score + weight;
							if weight == 2:
								weight = 0;
						else:
							score = score + 1;
							score = score + weight;
							if weight == 2:
								weight = 0;
					elif word_list[j][2] != '':
						if word_list[j][4] != '':
							score = score - 2;
							score = score - weight;
							if weight == 2:
								weight = 0;
					elif word_list[j][5] != '':
						score = score - 0.5;
						score = score - weight;
						if weight == 2:
							weight = 0;
						else:
							score = score - 1;
							score = score - weight;
							if weight == 2:
								weight = 0;
					elif word_list[j][8] != '':
						negate = 1;
						flag=1;
					elif word_list[j][6] != '':
						if flag == 1:
							score = 0;
							flag=0;
						else:
							weight = 2;
						"""
						score = score + x
						"""
					if score != 0:
						if negate == 1:
							score = score * (-1);
							negate = 0;
	#print i + " " + str(score)
	return score


stop_words = stopwords.words('english')
word_list = make_dictionary()
pos_list = pos_dictionary()
neg_list = neg_dictionary() 
#print neg_list
documents = [(list(movie_reviews.words(fileid)), category)
             for category in movie_reviews.categories()
             for fileid in movie_reviews.fileids(category)]

random.shuffle(documents)
features=[];
labels=[];
for i in range(len(documents)):
	features.append(documents[i][0])
	labels.append(documents[i][1])
#print features[1]
"""
get list of strings s
"""
string = "a very good movie"
print give_score(string,word_list,pos_list,neg_list,stopwords);
label_test = []
#for i in range(2000):
#	score = 0
#	for j in range(len(features[i])):
#		score = score + give_score(features[i][j],word_list,pos_list,neg_list,stopwords)
#	if score > 0:
#		label_test.append('pos');
#	else:
#		label_test.append('neg');
#	#print score
#count = 0
#for i in range(2000):
#	if labels[i] == label_test[i]:
#		count += 1;
#print count
#score = give_score(string,word_list,pos_list,neg_list,stopwords)
#print score