import nltk
from nltk.stem import *
from nltk.corpus import sentiwordnet as swn
string_content='The match was abandoned due to rain.';
token = nltk.word_tokenize(string_content);
tagged= nltk.pos_tag(token);
print tagged