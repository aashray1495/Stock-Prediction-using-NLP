#include<bits/stdc++.h>
using namespace std;
int main()
{
	int t;
	scanf("%d",&t);
	cout<<"1"<<endl;
	while(t--)
	{
		int n;
		cout<<"1"<<endl;
		scanf("%d",&n);
		int a[n],temp[1005]={0};
		for(int i=0;i<n;i++)
		{
			scanf("%d",&a[i]);
			temp[a[i]]++;
		}
		int flag=0,counter=0,ans=1;
		for(int i=1004;i>=0;i--)
		{
			if(temp[i]>=2)
			{
				ans*=i;
				counter++;
			}
			if(counter==2)
				break;
		}
		cout<<ans<<endl;
		if(counter<2)
			printf("-1\n");
		else
			printf("%d\n",ans);
	}
}