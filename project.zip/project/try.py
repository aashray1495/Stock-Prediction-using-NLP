import nltk
from nltk.stem import *
from nltk.corpus import sentiwordnet as swn
content = '';
z = swn.senti_synsets('plant')
print z;
for j in range(1,1608):
	f = open('data_main/tcs/tcs'+str(j)+'.txt','rb');
	arr = []
	string_content = f.read();
	token = nltk.word_tokenize(string_content);
	
	tagged=nltk.pos_tag(token);
	if(j==1):
		print tagged
	pscore = 0
	nscore = 0
	for i in range(0,len(tagged)):
	    if 'NN' in tagged[i][1] and len(swn.senti_synsets(tagged[i][0],'n'))>0:
	        pscore+=(list(swn.senti_synsets(tagged[i][0],'n'))[0]).pos_score() #positive score of a word
	        nscore+=(list(swn.senti_synsets(tagged[i][0],'n'))[0]).neg_score()  #negative score of a word
	    elif 'VB' in tagged[i][1] and len(swn.senti_synsets(tagged[i][0],'v'))>0:
	        pscore+=(list(swn.senti_synsets(tagged[i][0],'v'))[0]).pos_score()
	        nscore+=(list(swn.senti_synsets(tagged[i][0],'v'))[0]).neg_score()
	    elif 'JJ' in tagged[i][1] and len(swn.senti_synsets(tagged[i][0],'a'))>0:
	        pscore+=(list(swn.senti_synsets(tagged[i][0],'a'))[0]).pos_score()
	        nscore+=(list(swn.senti_synsets(tagged[i][0],'a'))[0]).neg_score()
	    elif 'RB' in tagged[i][1] and len(swn.senti_synsets(tagged[i][0],'r'))>0:
	        pscore+=(list(swn.senti_synsets(tagged[i][0],'r'))[0]).pos_score()
	        nscore+=(list(swn.senti_synsets(tagged[i][0],'r'))[0]).neg_score()
	content = content + str(pscore) + ',' + str(nscore) + '\n';
	if(j==15):
		print pscore
		print nscore
