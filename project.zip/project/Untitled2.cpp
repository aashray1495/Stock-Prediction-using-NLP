#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n,m;
    cin>>n>>m;
    char a[n][m];
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<m;j++)
        {
            cin>>a[i][j];
        }
    }
    int flag1=0,flag2=0,row,col;
    for(int i=0;i<n;i++)
    {
        flag1=0;
        for(int j=0;j<m;j++)
        {
            if(a[i][j]=='*');
            else
            {
                flag1=1;
                break;
            }
        }
        if(flag1==0)
        {
            row=i;
            break;
        }
    }
    for(int j=0;j<m;j++)
    {
        for(int i=0;i<n;i++)
        {
            if(a[i][j]=='*');
            else
            {
                flag2=1;
                break;
            }
        }
        if(flag2==0)
        {
            col=j;
            break;
        }
    }
    if(flag1==0 && flag2==0)
    {
        cout<<"YES"<<endl<<row+1<<" "<<col+1<<endl;
    }
    else
    {
        cout<<"NO"<<endl;
    }
}
