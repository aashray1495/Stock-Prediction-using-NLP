import csv
import datetime
import math
def validate(date_text):
    try:
        datetime.datetime.strptime(date_text, '%Y-%m-%d')
        return 1;
    except ValueError:
        return 0;
date_temp = [];
time = [];
temp = [];
date = [];
date.append('\0');
time.append('\0');
init_date=[]
with open('data_main/tcs_news_dates.csv','rb') as csvfile:	
	reader = csv.reader(csvfile)
	for row in reader:
		init_date.append(row[0].strip());
		date_temp = (row[0].strip().split(' '));
		if date_temp[1] == 'Jan':
			date_temp[1] = '01';
		elif date_temp[1] == 'Feb':
			date_temp[1] = '02';
		elif date_temp[1] == 'Mar':
			date_temp[1] = '03';
		elif date_temp[1] == 'Apr':
			date_temp[1] = '04';
		elif date_temp[1] == 'May':
			date_temp[1] = '05';
		elif date_temp[1] == 'Jun':
			date_temp[1] = '06';
		elif date_temp[1] == 'Jul':
			date_temp[1] = '07';
		elif date_temp[1] == 'Aug':
			date_temp[1] = '08';
		elif date_temp[1] == 'Sep':
			date_temp[1] = '09';
		elif date_temp[1] == 'Oct':
			date_temp[1] = '10';
		elif date_temp[1] == 'Nov':
			date_temp[1] = '11';
		elif date_temp[1] == 'Dec':
			date_temp[1] = '12';
		date_temp[2] = date_temp[2].decode('utf-8').replace(u'\xa0','').encode('utf-8');
		date.append(date_temp);
		time.append(row[1].strip());

new_time = []
new_time.append('\0');

for i in range(1,len(time)):
	timer = time[i].split(' ');
	hour_min = timer[0].split('.');
	if timer[1] == 'am':
		if(hour_min[0] == '12'):
			hour_min[0] = '00';
	else:
		hour_min[0] = str(int(hour_min[0])+12);
	string = hour_min[0] + ':' + hour_min[1];
	new_time.append(string);

price_date_temp = [];
price_date = [];
open_price = [];
high_price = [];
low_price = [];
close_price = [];
no_of_shares = [];
with open('data_main/tcs_stock.csv','rb') as csvfile:
	reader = csv.reader(csvfile)
	for row in reader:
		price_date_temp = (row[0].strip().split('-'));
		price_date.append(price_date_temp);
		open_price.append(row[1]);
		high_price.append(row[2]);
		low_price.append(row[3]);
		close_price.append(row[4]);
		no_of_shares.append(row[5]);

positive = [];
negative = [];
neutral = [];
sentiment = [];
positive.append(0);
negative.append(0);
neutral.append(0);
with open('data_main/news_score.csv','rb') as csvfile:
	reader = csv.reader(csvfile)
	for row in reader:
		positive.append(row[0]);
		negative.append(row[1]);
		neutral.append(row[2]);

news_time = [];

news_score_pos = [[[0 for k in xrange(32)] for j in xrange(14)] for i in xrange(6)];
news_score_neg = [[[0 for k in xrange(32)] for j in xrange(14)] for i in xrange(6)];
news_score_neutral = [[[0 for k in xrange(32)] for j in xrange(14)] for i in xrange(6)];
news_score = [[[0 for k in xrange(32)] for j in xrange(14)] for i in xrange(6)];


i = len(close_price)-1;
while i > 0 :
	index = [];
	for j in range(1,len(date)):
		if price_date[i] == date[j]:
			news_time.append(new_time[j]);
			index.append(j);
	q = 0;
	if len(index)>0:
		for j in index:
			time_array = news_time[q].split(':');
			if int(time_array[0]) >= 9:
				string1 = price_date[i][2] + "-" + price_date[i][1] + "-" + str(int(price_date[i][0])+1);
				string2 = price_date[i][2] + str(int(price_date[i][1])+1) + '-01';
				string3 = str(int(price_date[i][2])+1) + '-01-01';
				if(validate(string1)):
					news_score_pos[int(price_date[i][2])-2013][int(price_date[i][1])][int(price_date[i][0])+1] += float(positive[j]);
					news_score_neg[int(price_date[i][2])-2013][int(price_date[i][1])][int(price_date[i][0])+1] += float(negative[j]);
					news_score_neutral[int(price_date[i][2])-2013][int(price_date[i][1])][int(price_date[i][0])+1] += float(neutral[j]);
				elif(validate(string2)):
					news_score_pos[int(price_date[i][2])-2013][int(price_date[i][1])+1][1] += float(positive[j]);
					news_score_neg[int(price_date[i][2])-2013][int(price_date[i][1])+1][1] += float(negative[j]);
					news_score_neutral[int(price_date[i][2])-2013][int(price_date[i][1])+1][1] += float(neutral[j]);
				else:
					news_score_pos[int(price_date[i][2])-2012][1][1] += float(positive[j]);
					news_score_neg[int(price_date[i][2])-2012][1][1] += float(negative[j]);
					news_score_neutral[int(price_date[i][2])-2012][1][1] += float(neutral[j]);
				
			else:
				#print positive[j]
				news_score_pos[int(price_date[i][2])-2013][int(price_date[i][1])][int(price_date[i][0])] += float(positive[j]);
				news_score_neg[int(price_date[i][2])-2013][int(price_date[i][1])][int(price_date[i][0])] += float(negative[j]);
				news_score_neutral[int(price_date[i][2])-2013][int(price_date[i][1])][int(price_date[i][0])] += float(neutral[j]);
			q+=1;
	i -= 1;

for i in range(5):
	for j in range(13):
		for k in range(32):
			#if(news_score_neutral[i][j][k]>=float((news_score_pos[i][j][k]+news_score_neg[i][j][k]+news_score_neutral[i][j][k]))/3):
			#	news_score[i][j][k]=0;
			if news_score_pos[i][j][k]>=news_score_neg[i][j][k]:
				news_score[i][j][k]=1;
				p = i;
				q = j;
				r = k;
				t = -1;
				for e in range(1,11):
					string1 = str(p+2013) + "-" + str(q) + "-" + str(r+e);
					if(validate(string1)):
						news_score_pos[p][q][r+e] += math.exp(-e)*news_score_pos[i][j][k];
					else:
						t = e;
						break;
				if e != 10:
					r=1;
					for e in range(t,11):
						string1 = str(p+2013) + "-" + str(q+1) + "-" + str(r);
						if(validate(string1)):
							news_score_pos[p][q+1][r] += math.exp(-e)*news_score_pos[i][j][k];
							r += 1;
						else:
							t = e;
							break;
				if e != 10:
					q=1;
					r=1;
					for e in range(t,11):
						string1 = str(p+2014) + "-" + str(q) + "-" + str(r);
						if(validate(string1)):
							news_score_pos[p+1][q][r] += math.exp(-e)*news_score_pos[i][j][k];
							r += 1; 
			else:
				news_score[i][j][k]=-1;
				p = i;
				q = j;
				r = k;
				t = -1;
				for e in range(1,11):
					string1 = str(p+2013) + "-" + str(q) + "-" + str(r+e);
					if(validate(string1)):
						news_score_neg[p][q][r+e] += math.exp(-e)*news_score_neg[i][j][k];
					else:
						t = e;
						break;
				if e != 10:
					r=1;
					for e in range(t,11):
						string1 = str(p+2013) + "-" + str(q+1) + "-" + str(r);
						if(validate(string1)):
							news_score_neg[p][q+1][r] += math.exp(-e)*news_score_neg[i][j][k];
							r += 1;
						else:
							t = e;
							break;
				if e != 10:
					q=1;
					r=1;
					for e in range(t,11):
						string1 = str(p+2014) + "-" + str(q) + "-" + str(r);
						if(validate(string1)):
							news_score_neg[p+1][q][r] += math.exp(-e)*news_score_neg[i][j][k];
							r += 1; 
		
label = [];
label.append(0);
label.append(1);
for i in range(2,len(price_date)):
	if close_price[i]>close_price[i-1]:
		#if float(close_price[i])-float(close_price[i-1])/float(close_price[i])>0.01:
		label.append(-1);
		#else:
		#	label.append(0);
	elif close_price[i]<close_price[i-1]:
		#if float(close_price[i-1])-float(close_price[i])/float(close_price[i])>0.01:
		label.append(1);
		#else:
		#	label.append(0);
	else:
		label.append(0);

feature_test = [];
feature_train = [];
label_test = [];
label_train = [];
news_score_1 = [];
predict_date_index = [];
predict_date_index_train = [];
predict_date_index_test = [];
news_score_1.append(0);

for e in range(1,len(price_date)):
	news_score_1.append(news_score[int(price_date[e][2])-2013][int(price_date[e][1])][int(price_date[e][0])]);
		


inv_close_price_train = [];
inv_close_price_test = [];
open_test = [];
open_train = [];
x_axis = [];
y_axis = [];



import numpy as np;
np.seterr(divide='ignore', invalid='ignore')
print len(news_score_1)
print len(price_date)
for i in range(1,651):
	feature_train.append(news_score_1[i]);
	label_train.append(label[i]);
	predict_date_index_train.append(price_date[i]);
	inv_close_price_train.append(float(close_price[i]));
	open_train.append(float(open_price[i]));
for i in range(651,865):
	#if i == 478:
	#	print str(news_score_1[i]) + " " + str(close_price[predict_date_index[i]]) + " " + str(close_price[predict_date_index[i-1]]) + " " + str(predict_date_index[i])
	feature_test.append(news_score_1[i]);
	label_test.append(label[i]);
	predict_date_index_test.append(price_date[i]);
	inv_close_price_test.append(float(close_price[i]));
	open_test.append(float(open_price[i]));

feature_train = np.array(feature_train).reshape(-1,1)
label_train = np.array(label_train)

feature_test = np.array(feature_test).reshape(-1,1)
label_test = np.array(label_test)

initial_money = 1000000;

counter=0
from sklearn.ensemble import AdaBoostClassifier;
#clf = svm.SVC(C=1,gamma=1,kernel='rbf')
clf = AdaBoostClassifier()
clf.fit(feature_train,label_train);
pred = clf.predict(feature_test);
from sklearn.metrics import accuracy_score
print accuracy_score(label_test,pred);
for i in range(len(pred)):
	if feature_test[i] == -1:
		sell_price = open_test[i-1];
		buy_price = inv_close_price_test[i-1];
		print str(i+651) + " " + str(sell_price) + " " + str(buy_price)
		initial_money = initial_money + float(200*(sell_price-buy_price));
	else:
		buy_price = open_test[i-1];
		sell_price = inv_close_price_test[i-1];
		initial_money = initial_money + float(200*(sell_price-buy_price));
	if(feature_test[i]==label_test[i] and label_test[i] == 1):
		counter+=1;
	x_axis.append(i);	
	y_axis.append(initial_money);
counter1=0;
for i in range(len(label_test)):
	if label_test[i] == 1:
		counter1 += 1;
print initial_money
print str(counter) + " " + str(counter1)


print pred
initial_money = 1000000
counter=0

#print pred
import matplotlib.pyplot as plt
plt.figure(1)
plt.subplot(211)
plt.plot(x_axis,y_axis)
plt.subplot(212)
plt.plot(x_axis,inv_close_price_test,'r')
plt.show()


