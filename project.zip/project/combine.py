import csv
data1 = [];
data2 = [];
with open('data_main/tcs_score1.csv','rb') as csvfile:
	reader = csv.reader(csvfile)
	for row in reader:
		data1.append(row);
with open('data_main/tcs_scores.csv','rb') as csvfile:
	reader = csv.reader(csvfile)
	for row in reader:
		data2.append(row);
for i in range(len(data1)):
	if(data1[i][0]==''):
		data1[i]=data2[i];
content = '';
for i in range(len(data1)):
	content = content + data1[i][0] + ',' + data1[i][1] + ',' + data1[i][2] + "\n";
text_file = open('data_main/news_score.csv','w');
text_file.write(content);
text_file.close()
