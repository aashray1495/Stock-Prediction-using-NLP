from nltk.sentiment.vader import SentimentIntensityAnalyzer
from nltk import tokenize
f = open('data_main/tcs/tcs3.txt','rb');
paragraph=f.read()
lines_list = tokenize.sent_tokenize(paragraph);
sid=SentimentIntensityAnalyzer()
print sid.polarity_scores(paragraph);
