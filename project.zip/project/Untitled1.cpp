#include<bits/stdc++.h>
using namespace std;
int main()
{
    string n;
    cin>>n;
    int len=n.length();
    int num;
    if(len%2==0)
    {
        num=len/2;
    }
    else
    {
        num=len/2+1;
    }
    int l1=0,l2=0;
    for(int i=0;i<len;i++)
    {
        if(n[i]=='0'||n[i]=='1'||n[i]=='2'||n[i]=='3'||n[i]=='4')
        {
           if(l1<num)
           {
                n[i]='4';
                l1++;
           }
           else
           {
                n[i]='7';
                l2++;
           }
            cout<<n[i];
        }
        else
        {
           if(l2<num)
           {
                n[i]='7';
                l2++;
           }
           else
           {
                n[i]='4';
                l1++;
           }
            cout<<n[i];
        }

    }
    if(l1==num && l2==num);
    else
    {
        if(l1==num)
        {
            cout<<'7'<<endl;
        }
        else
        {
            cout<<'4'<<endl;
        }
    }
}
