#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n;
    cin>>n;
    int x,a[n],b[n],c[n],d[n];
    for(int i=0;i<n;i++)
    {
        cin>>x;
        if(x==0)
        {
            a[0]=0;
            b[0]=0;
        }
        else if(x==1)
        {
            a[0]=0;
            b[0]=1;
        }
        else if(x==2)
        {
            a[0]=1;
            b[0]=0;
        }
        else
        {
            a[0]=1;
            b[0]=1;
        }
    }
    int counter=0;
    if(a[0]==1&&b[0]==1)
    {
        if(a[1]==0)
        {
            c[0]=1;
            d[0]=0;
        }
        else if(b[1]==0)
        {
            c[0]=0;
            d[0]=1;
        }
        else
        {
            c[0]=1;
            d[0]=0;
        }
    }
    else if(a[0]==1)
    {
        c[0]=1;
        d[0]=0;
    }
    else if(b[0]==1)
    {
        c[0]=0;
        d[0]=1;
    }
    else
    {
        c[0]=0;
        d[0]=0;
        counter++;
    }
    for(int i=1;i<n;i++)
    {
        if(a[i]==1 && b[i]==1)
        {
            if(c[i-1]==1)
            {
                c[i]=0;
                d[i]=1;
            }
            else if(d[i-1]==1)
            {
                c[i]=1;
                d[i]=0;
            }
            else
            {
                c[i]
            }
        }
    }
}
